package com.example.e4.rcp.todo.creatable;

import org.eclipse.e4.core.di.annotations.Creatable;

@Creatable
public class Dependent {
	public Dependent() {
		// placeholder
	}
}