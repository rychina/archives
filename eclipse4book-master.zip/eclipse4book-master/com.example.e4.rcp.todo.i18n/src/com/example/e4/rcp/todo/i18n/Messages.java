package com.example.e4.rcp.todo.i18n;

public final class Messages {
	public String buttonLoadData;
	public String txtSummary;
	public String txtDescription;
	
	public String part_deletion_button_deletetodo;

	public String toolbar_main_changelocale;

}
