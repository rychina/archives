package com.vogella.extensionpoint.definition;

public interface IGreeter {
	void greet();
}