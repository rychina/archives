Eclipse Rich Client Platform Example
====================================

This is the example code for the [Eclipse RCP training sessions](http://www.vogella.com/training/eclipse/eclipsercp.html) from vogella GmbH and from the [Eclipse Rich Client Platform book] (http://www.vogella.com/books/eclipsercp.html).

The master branch points typically to the latest release of the Eclipse RCP book, currently Eclipse 4.4. Branches represents the solutions for other releases, e.g., the eclipse43 contains the solutions for an older version of the  [Eclipse Rich Client Platform book] (http://www.vogella.com/books/eclipsercp.html).


