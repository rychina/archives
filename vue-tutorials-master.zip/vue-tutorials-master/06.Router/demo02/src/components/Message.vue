<template>
	<ul>
		<li>Message 01</li>
		<li>Message 02</li>
		<li>Message 03</li>
	</ul>
</template>