Example projects for Eclipse RCP and plug-in development from the vogella.com website
=====================================================================================

Projects should use the com.vogella prefix followed by the area they demonstrate, e.g., jface, swt, rcp and the like.

